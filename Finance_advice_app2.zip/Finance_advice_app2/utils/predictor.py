"""
utils/predictor.py
------------------
Real ML-powered prediction engine for AI Finance Intelligence Suite.
Models: Linear Regression | Random Forest | XGBoost

Predicts:
  - Future savings (month-by-month)
  - Overspending risk score (0–100)
  - Investment growth projection
"""

import numpy as np
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────
# SAFE IMPORTS — graceful fallback if libs missing
# ─────────────────────────────────────────
try:
    from sklearn.linear_model import LinearRegression
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    SKLEARN_OK = True
except ImportError:
    SKLEARN_OK = False

try:
    from xgboost import XGBRegressor
    XGBOOST_OK = True
except ImportError:
    XGBOOST_OK = False


# ─────────────────────────────────────────
# SYNTHETIC TRAINING DATA GENERATOR
# ─────────────────────────────────────────
def _generate_training_data(n_samples: int = 500):
    """
    Generates realistic synthetic finance records.
    Features: [salary, emi, rent, food, travel, shopping, others, savings_rate]
    Targets : savings_next_month, overspend_risk (0-100), investment_growth
    """
    rng = np.random.default_rng(42)

    salary   = rng.uniform(20_000, 2_50_000, n_samples)
    emi      = salary * rng.uniform(0.05, 0.30, n_samples)
    rent     = salary * rng.uniform(0.10, 0.35, n_samples)
    food     = salary * rng.uniform(0.05, 0.20, n_samples)
    travel   = salary * rng.uniform(0.02, 0.10, n_samples)
    shopping = salary * rng.uniform(0.02, 0.15, n_samples)
    others   = salary * rng.uniform(0.01, 0.10, n_samples)

    total_exp    = emi + rent + food + travel + shopping + others
    savings      = salary - total_exp
    savings_rate = np.clip(savings / salary, -0.5, 1.0)

    # Target 1: next-month savings (slight random variation ±8%)
    savings_next = savings * rng.uniform(0.92, 1.08, n_samples)

    # Target 2: overspending risk 0-100
    overspend_risk = np.clip((total_exp / salary) * 100, 0, 100)
    overspend_risk += rng.normal(0, 3, n_samples)
    overspend_risk = np.clip(overspend_risk, 0, 100)

    # Target 3: investment growth % over 12 months
    # Higher savings_rate → higher growth (compounding proxy)
    inv_growth = np.clip(savings_rate * 18 + rng.normal(2, 2, n_samples), -5, 40)

    X = np.column_stack([salary, emi, rent, food, travel, shopping, others, savings_rate])
    y_savings  = savings_next
    y_risk     = overspend_risk
    y_inv      = inv_growth

    return X, y_savings, y_risk, y_inv


# ─────────────────────────────────────────
# MODEL TRAINING (done once, cached in module)
# ─────────────────────────────────────────
_models_cache = {}

def _train_models():
    """Train all three models and cache them."""
    global _models_cache
    if _models_cache:
        return _models_cache          # already trained this session

    X, y_sav, y_risk, y_inv = _generate_training_data()

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    results = {"scaler": scaler, "trained": True}

    # ── Linear Regression ─────────────────
    if SKLEARN_OK:
        lr_sav  = LinearRegression().fit(X_scaled, y_sav)
        lr_risk = LinearRegression().fit(X_scaled, y_risk)
        lr_inv  = LinearRegression().fit(X_scaled, y_inv)
        results["lr"] = {"savings": lr_sav, "risk": lr_risk, "investment": lr_inv}

    # ── Random Forest ─────────────────────
    if SKLEARN_OK:
        rf_sav  = RandomForestRegressor(n_estimators=100, random_state=42).fit(X, y_sav)
        rf_risk = RandomForestRegressor(n_estimators=100, random_state=42).fit(X, y_risk)
        rf_inv  = RandomForestRegressor(n_estimators=100, random_state=42).fit(X, y_inv)
        results["rf"] = {"savings": rf_sav, "risk": rf_risk, "investment": rf_inv}

    # ── XGBoost ───────────────────────────
    if XGBOOST_OK:
        xgb_sav  = XGBRegressor(n_estimators=100, learning_rate=0.1,
                                 max_depth=4, random_state=42, verbosity=0).fit(X, y_sav)
        xgb_risk = XGBRegressor(n_estimators=100, learning_rate=0.1,
                                 max_depth=4, random_state=42, verbosity=0).fit(X, y_risk)
        xgb_inv  = XGBRegressor(n_estimators=100, learning_rate=0.1,
                                 max_depth=4, random_state=42, verbosity=0).fit(X, y_inv)
        results["xgb"] = {"savings": xgb_sav, "risk": xgb_risk, "investment": xgb_inv}

    _models_cache = results
    return results


# ─────────────────────────────────────────
# FEATURE BUILDER
# ─────────────────────────────────────────
def _build_features(salary, emi, rent, food, travel, shopping, others):
    total_exp    = emi + rent + food + travel + shopping + others
    savings_rate = (salary - total_exp) / salary if salary > 0 else 0
    savings_rate = np.clip(savings_rate, -0.5, 1.0)
    return np.array([[salary, emi, rent, food, travel, shopping, others, savings_rate]])


# ─────────────────────────────────────────
# ENSEMBLE PREDICT HELPER
# ─────────────────────────────────────────
def _ensemble_predict(models, X_raw, X_scaled, target_key):
    """Average predictions from all available models."""
    preds = []
    if "lr" in models and SKLEARN_OK:
        preds.append(models["lr"][target_key].predict(X_scaled)[0])
    if "rf" in models and SKLEARN_OK:
        preds.append(models["rf"][target_key].predict(X_raw)[0])
    if "xgb" in models and XGBOOST_OK:
        preds.append(models["xgb"][target_key].predict(X_raw)[0])
    return float(np.mean(preds)) if preds else 0.0


# ═══════════════════════════════════════════════════════════════
# PUBLIC API — called from home.py / app.py
# ═══════════════════════════════════════════════════════════════

def predict_next_month_savings(history: list) -> float:
    """
    Legacy-compatible entry point used in home.py.
    Accepts a list of recent savings values; returns ML-predicted next-month savings.
    Falls back gracefully if sklearn/xgboost missing.
    """
    if not history:
        return 0.0
    # Simple fallback: linear extrapolation
    if not SKLEARN_OK:
        diffs = [history[i+1] - history[i] for i in range(len(history)-1)]
        avg_diff = np.mean(diffs) if diffs else 0
        return float(history[-1] + avg_diff)

    # Treat history as a tiny time-series; use index as feature
    X_ts = np.arange(len(history)).reshape(-1, 1)
    y_ts = np.array(history)
    model = LinearRegression().fit(X_ts, y_ts)
    next_x = np.array([[len(history)]])
    return float(model.predict(next_x)[0])


def predict_all(salary: float, emi: float, rent: float, food: float,
                travel: float, shopping: float, others: float) -> dict:
    """
    Full ML prediction using all three models (ensemble).

    Returns a dict:
    {
        "next_month_savings"  : float,   # ₹ predicted savings next month
        "overspend_risk"      : float,   # 0–100 risk score
        "investment_growth"   : float,   # % projected 12-month growth
        "model_breakdown"     : dict,    # per-model predictions
        "months_to_1L"        : float,
        "months_to_5L"        : float,
        "risk_label"          : str,     # "Low" | "Medium" | "High"
        "feature_importance"  : dict,    # from Random Forest
    }
    """
    if not SKLEARN_OK:
        # Graceful math fallback
        total_exp = emi + rent + food + travel + shopping + others
        savings   = max(salary - total_exp, 0)
        risk      = min((total_exp / salary * 100) if salary > 0 else 100, 100)
        return {
            "next_month_savings" : savings,
            "overspend_risk"     : risk,
            "investment_growth"  : max(savings / salary * 15, 0) if salary > 0 else 0,
            "model_breakdown"    : {},
            "months_to_1L"       : (100_000 / savings) if savings > 0 else float("inf"),
            "months_to_5L"       : (500_000 / savings) if savings > 0 else float("inf"),
            "risk_label"         : "High" if risk > 80 else "Medium" if risk > 50 else "Low",
            "feature_importance" : {},
            "fallback"           : True,
        }

    models   = _train_models()
    X_raw    = _build_features(salary, emi, rent, food, travel, shopping, others)
    X_scaled = models["scaler"].transform(X_raw)

    # ── Per-model predictions ──────────────
    breakdown = {}

    if "lr" in models:
        breakdown["LinearRegression"] = {
            "savings"    : float(models["lr"]["savings"].predict(X_scaled)[0]),
            "risk"       : float(np.clip(models["lr"]["risk"].predict(X_scaled)[0], 0, 100)),
            "investment" : float(models["lr"]["investment"].predict(X_scaled)[0]),
        }

    if "rf" in models:
        breakdown["RandomForest"] = {
            "savings"    : float(models["rf"]["savings"].predict(X_raw)[0]),
            "risk"       : float(np.clip(models["rf"]["risk"].predict(X_raw)[0], 0, 100)),
            "investment" : float(models["rf"]["investment"].predict(X_raw)[0]),
        }

    if "xgb" in models and XGBOOST_OK:
        breakdown["XGBoost"] = {
            "savings"    : float(models["xgb"]["savings"].predict(X_raw)[0]),
            "risk"       : float(np.clip(models["xgb"]["risk"].predict(X_raw)[0], 0, 100)),
            "investment" : float(models["xgb"]["investment"].predict(X_raw)[0]),
        }

    # ── Ensemble averages ──────────────────
    next_savings  = _ensemble_predict(models, X_raw, X_scaled, "savings")
    overspend     = float(np.clip(_ensemble_predict(models, X_raw, X_scaled, "risk"), 0, 100))
    inv_growth    = _ensemble_predict(models, X_raw, X_scaled, "investment")

    risk_label = "Low" if overspend < 50 else "Medium" if overspend < 80 else "High"

    months_to_1L = (100_000 / next_savings) if next_savings > 0 else float("inf")
    months_to_5L = (500_000 / next_savings) if next_savings > 0 else float("inf")

    # ── Feature importance (Random Forest) ─
    feat_names  = ["Salary","EMI","Rent","Food","Travel","Shopping","Others","SavingsRate"]
    feat_import = {}
    if "rf" in models:
        importances = models["rf"]["savings"].feature_importances_
        feat_import = dict(zip(feat_names, [round(float(v), 4) for v in importances]))

    return {
        "next_month_savings" : round(next_savings, 2),
        "overspend_risk"     : round(overspend, 1),
        "investment_growth"  : round(inv_growth, 2),
        "model_breakdown"    : breakdown,
        "months_to_1L"       : round(months_to_1L, 1),
        "months_to_5L"       : round(months_to_5L, 1),
        "risk_label"         : risk_label,
        "feature_importance" : feat_import,
        "fallback"           : False,
    }


def savings_projection(salary: float, emi: float, rent: float, food: float,
                       travel: float, shopping: float, others: float,
                       months: int = 12) -> list:
    """
    Returns a list of (month, projected_cumulative_savings) for charting.
    Uses XGBoost/RF ensemble with slight monthly noise to simulate real-world variation.
    """
    rng   = np.random.default_rng(0)
    result = predict_all(salary, emi, rent, food, travel, shopping, others)
    base  = result["next_month_savings"]

    projection = []
    cumulative = 0.0
    for m in range(1, months + 1):
        monthly = base * (1 + rng.normal(0, 0.04))   # ±4% realistic noise
        cumulative += max(monthly, 0)
        projection.append((m, round(cumulative, 2)))
    return projection
