def calculate_finances(salary, emi, rent, food, travel, shopping):
    total_expense = emi + rent + food + travel + shopping
    savings = salary - total_expense
    savings_rate = (savings / salary) * 100

    expense_distribution = {
        "EMI": emi,
        "Rent": rent,
        "Food": food,
        "Travel": travel,
        "Shopping": shopping
    }

    return total_expense, savings, savings_rate, expense_distribution