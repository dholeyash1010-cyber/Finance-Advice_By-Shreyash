import pandas as pd

def get_spending_insights(salary, expenses, df_full):
    """
    Compares user spending against the dataset for users in a similar salary bracket.
    """
    if df_full is None:
        return ["⚠️ Dataset not found. Comparative insights are unavailable."]
        
    insights = []
    
    # Define salary bracket (+/- 20% of current salary)
    bracket_min = salary * 0.8
    bracket_max = salary * 1.2
    
    # Filter dataset for similar users
    similar_users = df_full[(df_full['Salary'] >= bracket_min) & (df_full['Salary'] <= bracket_max)]
    
    if not similar_users.empty:
        for category, user_amt in expenses.items():
            if category in similar_users.columns:
                avg_spend = similar_users[category].mean()
                # Check if user is spending significantly more than average
                if user_amt > avg_spend:
                    diff_pct = ((user_amt - avg_spend) / avg_spend) * 100
                    insights.append(f"🚩 Your **{category}** expense is **{diff_pct:.0f}% higher** than users in your salary bracket.")

    # Practical Savings Tip
    food_reduction = expenses.get('Food', 0) * 0.15
    annual_gain = food_reduction * 12
    if annual_gain > 0:
        insights.append(f"💡 Reducing **food expense by 15%** could increase your annual savings by **₹{annual_gain:,.0f}**.")
    
    return insights
