def chatbot_response(msg, salary, expenses):
    msg = msg.lower()

    if "save" in msg:
        return "Ideally, save at least 20–30% of your income."

    if "food" in msg:
        return "Food expenses shouldn’t exceed 10–15% of salary."

    if "rent" in msg:
        return "Rent should ideally be under 30% of salary."

    if "suggest" in msg or "advice" in msg:
        return "Reduce non-essential costs & maintain a monthly budget."

    if "overspending" in msg:
        if expenses > salary:
            return "Yes, you’re overspending. Cut at least 10–15% of variable costs."
        return "You are not overspending compared to your salary."

    return "I can help with budgeting, saving, planning & financial health!"