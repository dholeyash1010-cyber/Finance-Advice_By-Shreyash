def step_by_step_advice(salary, emi, rent, food, travel, shopping):
    total_expense = emi + rent + food + travel + shopping
    savings = salary - total_expense
    saving_rate = (savings / salary * 100) if salary > 0 else 0

    advice = []

    # Step 1: Salary analysis
    advice.append(f"1️⃣ **Your monthly salary is:** ₹{salary}")

    # Step 2: Expense breakdown
    advice.append("2️⃣ **Your monthly expenses are:**")
    advice.append(f"   • EMI: ₹{emi}")
    advice.append(f"   • Rent: ₹{rent}")
    advice.append(f"   • Food: ₹{food}")
    advice.append(f"   • Travel: ₹{travel}")
    advice.append(f"   • Shopping/Entertainment: ₹{shopping}")
    advice.append(f"👉 **Total Monthly Expense = ₹{total_expense}**")

    # Step 3: Savings calculation
    advice.append("3️⃣ **Savings Calculation:**")
    if savings >= 0:
        advice.append(f"   • Savings = Salary – Expenses = ₹{salary} – ₹{total_expense} = ₹{savings}")
    else:
        advice.append(f"   • You are overspending by ₹{-savings}")

    advice.append(f"👉 **Savings Rate = {saving_rate:.2f}%**")

    # Step 4: Interpretation
    advice.append("4️⃣ **Interpretation of your financial health:**")

    if total_expense > salary:
        advice.append("⚠️ Your expenses are MORE than your income. This is financially dangerous.")
    elif saving_rate < 20:
        advice.append("⚠️ Your savings are below recommended 20%. You need to reduce expenses.")
    elif 20 <= saving_rate <= 40:
        advice.append("👍 Your savings rate is decent. You are managing finances moderately well.")
    else:
        advice.append("🔥 Excellent savings rate! You are financially very stable.")

    # Step 5: Personalized recommendations
    advice.append("5️⃣ **Personalized Recommendations:**")

    if emi > 0.3 * salary:
        advice.append("   • Your EMI is too high (more than 30% of salary). Try refinancing or reducing loans.")

    if rent > 0.3 * salary:
        advice.append("   • Rent is above 30% of income. Consider a more affordable place.")

    if food > 0.15 * salary:
        advice.append("   • Food expenses are high. Try meal planning / home cooking.")

    if travel > 0.10 * salary:
        advice.append("   • Travel expenses exceed safe limit. Find cheaper commute options.")

    if shopping > 0.10 * salary:
        advice.append("   • Reduce shopping/entertainment. Target ≤10% of salary.")

    # Step 6: Final Conclusion
    advice.append("6️⃣ **Conclusion:**")
    if savings < 0:
        advice.append("❗ You MUST cut down spending immediately to avoid debt.")
    elif saving_rate < 20:
        advice.append("💡 Try to increase your savings to at least 20% of salary.")
    else:
        advice.append("✅ You are on the right financial track. Keep saving consistently.")

    return "\n".join(advice)
