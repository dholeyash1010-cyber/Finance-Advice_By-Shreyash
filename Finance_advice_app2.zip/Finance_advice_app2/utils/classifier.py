import pandas as pd

def classify_expenses(df):
    """
    Scans 'Description' and 'Amount' columns to map to app categories.
    """
    mapping = {
        'Food': ['swiggy', 'zomato', 'restaurant', 'mcdonalds', 'starbucks', 'grocery', 'blinkit', 'zepto'],
        'Travel': ['uber', 'ola', 'rapido', 'irctc', 'petrol', 'shell', 'indigo', 'makemytrip'],
        'Shopping': ['amazon', 'flipkart', 'myntra', 'zara', 'h&m', 'reliance', 'nykaa'],
        'Rent': ['rent', 'house', 'maintenance', 'nobroker'],
        'EMI': ['loan', 'emi', 'hdfc', 'icici', 'sbi', 'axis', 'lic']
    }

    results = {'Salary': 0.0, 'EMI': 0.0, 'Rent': 0.0, 'Food': 0.0, 'Travel': 0.0, 'Shopping': 0.0, 'Others': 0.0}
    
    # Standardize column names to match
    df.columns = [c.strip().capitalize() for c in df.columns]
    
    if 'Description' in df.columns and 'Amount' in df.columns:
        for _, row in df.iterrows():
            desc = str(row['Description']).lower()
            try:
                amt = abs(float(str(row['Amount']).replace(',', '')))
            except:
                continue
                
            found = False
            for category, keywords in mapping.items():
                if any(k in desc for k in keywords):
                    results[category] += amt
                    found = True
                    break
            
            if not found:
                # Basic check for Salary (Credits)
                if 'salary' in desc or 'wages' in desc:
                    results['Salary'] += amt
                else:
                    results['Others'] += amt
                
    return results
