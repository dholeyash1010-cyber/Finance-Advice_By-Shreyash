import streamlit as st

def show_homepage():
    # =========================================
    # PREMIUM CSS
    # =========================================
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}

    html, body, [data-testid="stAppViewContainer"], [data-testid="stApp"] {
        background-color: #e6f4f1 !important; /* Light Bottle Green */
        color: #041b16 !important;           /* Dark Bottle Green */
        font-family: 'DM Sans', sans-serif !important;
    }

    .block-container {
        padding: 0 !important;
        max-width: 100% !important;
    }

    /* ---- NAVBAR ---- */
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 22px 60px;
        border-bottom: 1px solid rgba(4, 27, 22, 0.1);
        background: rgba(230, 244, 241, 0.95);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .nav-logo {
        font-family: 'Sora', sans-serif;
        font-size: 20px;
        font-weight: 800;
        letter-spacing: 3px;
        color: #059669; /* Emerald Green */
    }
    .nav-logo span { color: #041b16; }

    /* ---- HERO ---- */
    .hero-section {
        min-height: 90vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 80px 40px;
        background:
            radial-gradient(ellipse 70% 60% at 50% 20%, rgba(5, 150, 105, 0.15) 0%, transparent 70%),
            linear-gradient(180deg, #e6f4f1 0%, #d7eee3 100%);
        position: relative;
        overflow: hidden;
    }
    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(5, 150, 105, 0.1);
        border: 1px solid rgba(5, 150, 105, 0.3);
        border-radius: 50px;
        padding: 8px 20px;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 2px;
        color: #059669;
        margin-bottom: 10px;
    }
    .hero-h1 {
        font-family: 'Sora', sans-serif;
        font-size: clamp(48px, 7vw, 88px);
        font-weight: 800;
        line-height: 1.05;
        letter-spacing: -2px;
        color: #041b16;
        margin: 0 0 28px 0;
        max-width: 900px;
    }
    .hero-h1 .accent { color: #059669; }
    .hero-p {
        font-size: 19px;
        line-height: 1.7;
        color: #2d4a43;
        max-width: 620px;
        margin: 0 auto 60px auto;
        font-weight: 400;
    }

    /* ---- FEATURES ---- */
    .features-section {
        background: #f0f9f6;
        padding: 100px 60px;
        border-top: 1px solid rgba(4, 27, 22, 0.05);
    }
    .features-label {
        text-align: center;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 3px;
        color: #059669;
        margin-bottom: 16px;
    }
    .features-title {
        font-family: 'Sora', sans-serif;
        text-align: center;
        font-size: 42px;
        font-weight: 700;
        color: #041b16;
        margin-bottom: 70px;
        letter-spacing: -1px;
    }
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 24px;
        max-width: 1200px;
        margin: 0 auto;
    }
    .feat-card {
        background: #ffffff;
        border: 1px solid rgba(4, 27, 22, 0.1);
        border-radius: 20px;
        padding: 36px 32px;
        transition: border-color 0.3s;
    }
    .feat-card:hover { border-color: rgba(5, 150, 105, 0.35); }
    .feat-icon {
        width: 50px; height: 50px;
        border-radius: 14px;
        background: rgba(5, 150, 105, 0.1);
        border: 1px solid rgba(5, 150, 105, 0.2);
        display: flex; align-items: center; justify-content: center;
        font-size: 22px;
        margin-bottom: 22px;
    }
    .feat-title {
        font-family: 'Sora', sans-serif;
        font-size: 18px; font-weight: 700;
        color: #041b16;
        margin-bottom: 10px;
    }
    .feat-desc {
        font-size: 14px; line-height: 1.65;
        color: #2d4a43;
        font-weight: 400;
    }

    /* ---- SECURITY SECTION ---- */
    .security-section {
        padding: 100px 60px;
        background: #ffffff;
        text-align: center;
        border-top: 1px solid rgba(4, 27, 22, 0.05);
    }
    .security-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 40px;
        max-width: 1100px;
        margin: 50px auto 0 auto;
    }
    .security-icon { font-size: 40px; margin-bottom: 20px; color: #059669; }
    .security-h3 { font-family: 'Sora', sans-serif; font-size: 20px; font-weight: 700; color: #041b16; margin-bottom: 12px; }
    .security-p { font-size: 14px; color: #4f6b63; line-height: 1.6; }

    /* ---- FAQ SECTION ---- */
    .faq-section {
        padding: 100px 60px;
        background: #f0f9f6;
        border-top: 1px solid rgba(4, 27, 22, 0.05);
    }

    /* ---- STATS ---- */
    .stats-section {
        padding: 80px 60px;
        background: #e6f4f1;
        border-top: 1px solid rgba(4, 27, 22, 0.05);
    }
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 24px;
        max-width: 900px;
        margin: 0 auto;
    }
    .stat-box {
        text-align: center;
        padding: 32px 20px;
        background: #ffffff;
        border: 1px solid rgba(5, 150, 105, 0.15);
        border-radius: 18px;
    }
    .stat-num {
        font-family: 'Sora', sans-serif;
        font-size: 42px; font-weight: 800;
        color: #059669;
        line-height: 1;
        margin-bottom: 8px;
    }
    .stat-label {
        font-size: 13px; color: #2d4a43;
        font-weight: 500;
        letter-spacing: 1px;
    }

    /* ---- CTA SECTION ---- */
    .cta-section {
        padding: 100px 60px;
        text-align: center;
        background: linear-gradient(180deg, #f0f9f6 0%, #e6f4f1 100%);
        border-top: 1px solid rgba(4, 27, 22, 0.05);
    }
    .cta-title {
        font-family: 'Sora', sans-serif;
        font-size: 48px; font-weight: 800;
        color: #041b16;
        margin-bottom: 20px;
        letter-spacing: -1.5px;
    }
    .cta-sub { font-size: 17px; color: #2d4a43; margin-bottom: 50px; }

    /* ---- FOOTER ---- */
    .footer {
        background: #ffffff;
        border-top: 1px solid rgba(4, 27, 22, 0.05);
        padding: 30px 60px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .footer-logo {
        font-family: 'Sora', sans-serif;
        font-size: 15px; font-weight: 700;
        letter-spacing: 2px;
        color: #059669;
    }
    .footer-text { font-size: 13px; color: #3a6054; }

    /* ---- BUTTON OVERRIDES ---- */
    div.stButton > button {
        background: linear-gradient(135deg, #041b16, #0b2d26) !important;
        color: #e6f4f1 !important;
        font-family: 'DM Sans', sans-serif !important;
        font-weight: 600 !important;
        border-radius: 12px !important;
        height: 50px !important;
        font-size: 15px !important;
        transition: all 0.2s ease !important;
        border: none !important;
    }
    </style>
    """, unsafe_allow_html=True)

    # Navbar Content
    st.markdown('<div class="navbar"><div class="nav-logo">AI<span>FINANCE</span></div></div>', unsafe_allow_html=True)

    nav_spacer, nav_btn_col = st.columns([6, 1])
    with nav_btn_col:
        b1, b2 = st.columns(2)
        with b1:
            if st.button("Login", use_container_width=True, key="nav_login"):
                st.session_state.page = "login"
                st.rerun()
        with b2:
            if st.button("Sign Up", use_container_width=True, key="nav_signup"):
                st.session_state.page = "login"
                st.rerun()

    # Hero Section
    st.markdown("""
    <div class="hero-section">
        <div class="hero-badge">✦ &nbsp; POWERED BY MACHINE LEARNING</div>
        <h1 class="hero-h1">Your Finances,<br><span class="accent">Finally Intelligent.</span></h1>
        <p class="hero-p">
            Stop guessing. Start growing. AI Finance gives you real-time spending insights,
            predictive wealth forecasts, and executive-grade financial advisory — all in one place.
        </p>
    </div>
    """, unsafe_allow_html=True)

    _, cta_col1, cta_col2, _ = st.columns([2, 1, 1, 2])
    with cta_col1:
        if st.button("🚀  Get Started Free", use_container_width=True, key="hero_signup"):
            st.session_state.page = "login"
            st.rerun()
    with cta_col2:
        if st.button("🔐  Sign In", use_container_width=True, key="hero_login"):
            st.session_state.page = "login"
            st.rerun()

    # Features Section
    st.markdown("""
    <div class="features-section">
        <div class="features-label">WHAT WE OFFER</div>
        <div class="features-title">Built for serious wealth builders.</div>
        <div class="features-grid">
            <div class="feat-card">
                <div class="feat-icon">🤖</div>
                <div class="feat-title">AI Executive Advisor</div>
                <div class="feat-desc">Get personalized, step-by-step financial strategies generated from your actual spending data — not generic tips.</div>
            </div>
            <div class="feat-card">
                <div class="feat-icon">📈</div>
                <div class="feat-title">Wealth Forecasting</div>
                <div class="feat-desc">ML-powered 12-month savings projections show you exactly when you'll hit your next financial milestone.</div>
            </div>
            <div class="feat-card">
                <div class="feat-icon">⚡</div>
                <div class="feat-title">Optimization Engine</div>
                <div class="feat-desc">Instantly simulate the impact of cutting expenses. Find the minimum sacrifice for maximum financial growth.</div>
            </div>
            <div class="feat-card">
                <div class="feat-icon">📊</div>
                <div class="feat-title">Market Benchmarking</div>
                <div class="feat-desc">See how your savings rate ranks against thousands of real profiles in your income bracket.</div>
            </div>
            <div class="feat-card">
                <div class="feat-icon">🛡️</div>
                <div class="feat-title">Health Score System</div>
                <div class="feat-desc">A dynamic 0–100 financial health score that updates in real-time as you adjust your budget inputs.</div>
            </div>
            <div class="feat-card">
                <div class="feat-icon">📋</div>
                <div class="feat-title">Executive Audit Reports</div>
                <div class="feat-desc">One-click downloadable financial audit reports. Professional, formatted, and ready to act on.</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Security Section
    st.markdown("""
    <div class="security-section">
        <div class="features-label">SECURITY FIRST</div>
        <div class="features-title">Your data is yours. Period.</div>
        <div class="security-grid">
            <div class="security-card">
                <div class="security-icon">🛡️</div>
                <div class="security-h3">Bank-Grade Encryption</div>
                <div class="security-p">All financial data is processed using 256-bit AES encryption, ensuring your numbers stay private.</div>
            </div>
            <div class="security-card">
                <div class="security-icon">👤</div>
                <div class="security-h3">Zero Data Selling</div>
                <div class="security-p">We never sell your behavior to third parties. Our business model is built on your growth, not your data.</div>
            </div>
            <div class="security-card">
                <div class="security-icon">⚡</div>
                <div class="security-h3">Private AI Processing</div>
                <div class="security-p">Our ML models analyze your data locally within your session. We don't store your personal spending habits.</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # FAQ Section
    st.markdown("""
    <div class="faq-section">
        <div class="features-label" style="text-align: center;">QUESTIONS?</div>
        <div class="features-title" style="text-align: center; margin-bottom: 50px;">Commonly Asked Questions</div>
    </div>
    """, unsafe_allow_html=True)

    _, faq_col, _ = st.columns([1, 2, 1])
    with faq_col:
        with st.expander("How accurate are the 12-month wealth projections?"):
            st.write("Our models use historical trend analysis. Our current accuracy rate for users with consistent inputs is roughly 94%.")
        with st.expander("Do I need to connect my bank account?"):
            st.write("No. AI Finance is built for privacy. You can manually input your high-level expenses to get a full audit without linking bank credentials.")
        with st.expander("Can I download my financial audit reports?"):
            st.write("Yes. Every analysis generates a professional, executive-formatted audit report that you can download as a text file.")
        with st.expander("Is there a mobile app?"):
            st.write("Currently, AI Finance is a web-based suite optimized for mobile browsers, allowing you to access your dashboard on any device.")

    # Stats Section
    st.markdown("""
    <div class="stats-section">
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-num">50K+</div>
                <div class="stat-label">Users Analyzed</div>
            </div>
            <div class="stat-box">
                <div class="stat-num">₹2.4Cr</div>
                <div class="stat-label">Avg. Savings Optimized</div>
            </div>
            <div class="stat-box">
                <div class="stat-num">94%</div>
                <div class="stat-label">Forecast Accuracy</div>
            </div>
            <div class="stat-box">
                <div class="stat-num">12s</div>
                <div class="stat-label">Time to Full Analysis</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # CTA Section
    st.markdown("""
    <div class="cta-section">
        <div class="cta-title">Ready to take control?</div>
        <div class="cta-sub">Join thousands building wealth intelligently. It's free to start.</div>
    </div>
    """, unsafe_allow_html=True)

    _, cta2_col1, cta2_col2, _ = st.columns([2, 1, 1, 2])
    with cta2_col1:
        if st.button("Create Free Account", use_container_width=True, key="cta_signup"):
            st.session_state.page = "login"
            st.rerun()
    with cta2_col2:
        if st.button("Sign In Now", use_container_width=True, key="cta_login"):
            st.session_state.page = "login"
            st.rerun()

    # Footer
    st.markdown("""
    <div class="footer">
        <div class="footer-logo">AIFINANCE</div>
        <div class="footer-text">© 2024 AI Finance Intelligence Suite. All rights reserved.</div>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    if 'page' not in st.session_state:
        st.session_state.page = "home"
    show_homepage()
