import streamlit as st
import re
import json
import os
from datetime import datetime

# =========================================
# USER DATABASE STORAGE
# =========================================
USER_DB_FILE = "users_database.json"

def load_users():
    """Load user database from JSON file"""
    if os.path.exists(USER_DB_FILE):
        try:
            with open(USER_DB_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_users(users_dict):
    """Save user database to JSON file"""
    try:
        with open(USER_DB_FILE, 'w') as f:
            json.dump(users_dict, f, indent=4)
        return True
    except:
        return False

# =========================================
# EMAIL VALIDATION
# =========================================
def is_valid_email(email):
    """Validate email format"""
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email)

# =========================================
# PASSWORD VALIDATION
# =========================================
def validate_password(password):
    """
    Validate password strength
    Requirements:
    - Minimum 8 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character
    """
    errors = []
    
    if len(password) < 8:
        errors.append("Password must be at least 8 characters long")
    if not re.search(r'[A-Z]', password):
        errors.append("Password must contain at least one uppercase letter")
    if not re.search(r'[a-z]', password):
        errors.append("Password must contain at least one lowercase letter")
    if not re.search(r'\d', password):
        errors.append("Password must contain at least one digit")
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};:\'",.<>?]', password):
        errors.append("Password must contain at least one special character (!@#$%^&*)")
    
    return len(errors) == 0, errors

# =========================================
# USER MANAGEMENT FUNCTIONS
# =========================================
def user_exists(email):
    """Check if user is already registered"""
    users = load_users()
    return email.lower() in users

def register_user(name, email, password):
    """Register a new user"""
    users = load_users()
    
    if user_exists(email):
        return False, "Email already registered. Please use Sign In or try another email."
    
    users[email.lower()] = {
        "name": name,
        "email": email.lower(),
        "password": password,
        "registered_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "last_login": None
    }
    
    if save_users(users):
        return True, "Account created successfully! Please Sign In."
    else:
        return False, "Error saving account. Please try again."

def authenticate_user(email, password):
    """Authenticate user credentials"""
    users = load_users()
    email_lower = email.lower()
    
    if email_lower not in users:
        return False, "Email not registered. Please create an account first."
    
    if users[email_lower]["password"] != password:
        return False, "Incorrect password. Please try again."
    
    # Update last login
    users[email_lower]["last_login"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_users(users)
    
    return True, f"Welcome back, {users[email_lower]['name']}!"

# =========================================
# FULL-SCREEN PREMIUM LOGIN PAGE
# =========================================
def login_user():
    # PREMIUM CSS
    st.markdown("""
    <style>
    /* 1. Hide default Streamlit UI */
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}
    [data-testid="stToolbar"] {visibility: hidden !important;}

    /* 2. Page Container & Main Background */
    .block-container {
        padding: 0rem 5rem !important;
        max-width: 100% !important;
    }
    
    [data-testid="stAppViewContainer"] {
        background: linear-gradient(135deg, #0d3d29 0%, #1a5a3d 45%, #2d8659 100%);
    }

    /* 3. Main Glass Card */
    .main-card {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(20px);
        border-radius: 35px;
        padding: 20px;
        width: 95%;
        max-width: 1300px;
        margin: 5vh auto;
        box-shadow: 0 25px 50px rgba(0,0,0,0.5);
    }

    /* 4. Left Panel Styling */
    [data-testid="column"]:nth-of-type(1) [data-testid="stVerticalBlock"] {
        background-color: #e8f5f0 !important; 
        border: 1px solid #a8d5b8 !important; 
        border-radius: 28px !important;
        padding: 45px !important;
        min-height: 700px !important;
    }

    /* --- FIX: LABELS & TABS FORCED TO WHITE --- */
    /* This targets input labels */
    label[data-testid="stWidgetLabel"] p {
        color: white !important;
        font-weight: 700 !important;
        font-size: 15px !important;
    }

    /* This targets the Tab text (Sign In / Create Account) */
    .stTabs [data-baseweb="tab"] p {
        color: white !important;
        font-weight: 700 !important;
    }

    /* Markdown headings to white */
    h4 {
        color: white !important;
    }

    /* --- INPUT BLOCK STYLING: KEEPS LIGHT GREEN --- */
[data-testid="stTextInput"] input {
    background-color: #ffffff !important; 
    color: #0d3d29 !important;           
    border: 2px solid #a8d5b8 !important; 
    border-radius: 10px !important;
    /* ADD THIS LINE BELOW */
    caret-color: #1a5a3d !important; 
}

    [data-testid="stTextInput"] input::placeholder {
        color: #2d8659 !important; 
        opacity: 0.6 !important;
    }

    /* 5. Right Image Panel */
    .right-panel {
        background: linear-gradient(rgba(13, 61, 41, 0.5), rgba(13, 61, 41, 0.85)),
                    url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop');
        background-size: cover;
        background-position: center;
        border-radius: 28px;
        height: 700px;
        padding: 50px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        color: white;
    }

    /* 6. Typography & UI Fixes */
/* 1. The small tag above the heading */
.brand-tag { 
    color: #D4AF37 !important; /* Gold color */
    font-size: 13px; 
    font-weight: 700; 
    letter-spacing: 2px; 
    text-transform: uppercase;
}

/* 2. The caption/subtitle below the heading */
.login-subtitle { 
    color: #A8D5B8 !important; /* Soft Mint for readability */
    font-size: 15px; 
    margin-bottom: 40px; 
    opacity: 0.9;
}  
.login-title {
    color: white !important;
    font-size: 48px;
    font-weight: 800;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3); /* Adds depth */
}    
    .stButton > button {
        background: linear-gradient(135deg, #1a5a3d, #2d8659);
        color: white !important;
        border-radius: 12px;
        height: 55px;
        font-weight: 700;
        border: none;
    }
    
    .divider {
        text-align: center;
        color: #2d8659;
        font-size: 13px;
        margin: 30px 0;
        border-bottom: 2px solid #c9e9dd;
        line-height: 0.1em;
    }
    .divider span { background:#e8f5f0; padding:0 15px; color: #0d3d29; font-weight: 600; }
    
    .validation-helper {
        background-color: #f0f9f7;
        border-left: 4px solid #2d8659;
        padding: 12px;
        border-radius: 8px;
        font-size: 13px;
        margin-top: 10px;
        color: #0d3d29;
    }
    </style>
    """, unsafe_allow_html=True)

    # RENDER THE CARD
    st.markdown('<div class="main-card">', unsafe_allow_html=True)
    l_col, r_col = st.columns([1, 1], gap="large")

    with l_col:
        st.markdown('<div class="brand-tag">🔐 AI FINANCE INTELLIGENCE</div>', unsafe_allow_html=True)
        st.markdown('<div class="login-title">Secure Access</div>', unsafe_allow_html=True)
        st.markdown('<div class="login-subtitle">Manage your wealth with executive-level financial intelligence</div>', unsafe_allow_html=True)

        tab_log, tab_reg = st.tabs(["🔐 Sign In", "📝 Create Account"])

        with tab_log:
            st.markdown("#### Sign In to Your Account")
            
            email_signin = st.text_input("Email Address", placeholder="name@example.com", key="login_em")
            pwd_signin = st.text_input("Password", type="password", placeholder="••••••••", key="login_pw")
            
            col1, col2 = st.columns([3, 1])
            with col1:
                if st.button("Sign In Securely", use_container_width=True, key="btn_signin"):
                    # Validation
                    if not email_signin.strip():
                        st.error("❌ Email address is required")
                    elif not is_valid_email(email_signin):
                        st.error("❌ Please enter a valid email format (e.g., name@example.com)")
                    elif not pwd_signin:
                        st.error("❌ Password is required")
                    else:
                        # Authenticate user
                        is_valid, message = authenticate_user(email_signin, pwd_signin)
                        if is_valid:
                            st.success(f"✅ {message}")
                            st.session_state.logged_in = True
                            st.session_state.user_email = email_signin
                            st.session_state.user_name = load_users()[email_signin.lower()]["name"]
                            st.balloons()
                            st.rerun()
                        else:
                            st.error(f"❌ {message}")
            
            with col2:
                if st.button("🔄", help="Reset form", key="btn_reset_signin"):
                    st.rerun()

        with tab_reg:
            st.markdown("#### Create Your Account")
            
            name_signup = st.text_input("Full Name", placeholder="John Doe", key="signup_name")
            email_signup = st.text_input("Email Address", placeholder="name@example.com", key="signup_em")
            pwd_signup = st.text_input("Password", type="password", placeholder="••••••••", key="signup_pw")
            pwd_confirm = st.text_input("Confirm Password", type="password", placeholder="••••••••", key="signup_pw_confirm")
            
            # Password strength indicator
            if pwd_signup:
                is_strong, errors = validate_password(pwd_signup)
                if is_strong:
                    st.markdown('<div class="validation-helper">✅ Password strength: <strong>Strong</strong></div>', unsafe_allow_html=True)
                else:
                    st.markdown('<div class="validation-helper">⚠️ Password must meet these requirements:<br>' + '<br>'.join([f'• {error}' for error in errors]) + '</div>', unsafe_allow_html=True)
            
            col1, col2 = st.columns([3, 1])
            with col1:
                if st.button("Create Account", use_container_width=True, key="btn_signup"):
                    # Validation
                    if not name_signup.strip():
                        st.error("❌ Full name is required")
                    elif len(name_signup.strip()) < 3:
                        st.error("❌ Name must be at least 3 characters long")
                    elif not email_signup.strip():
                        st.error("❌ Email address is required")
                    elif not is_valid_email(email_signup):
                        st.error("❌ Please enter a valid email format (e.g., name@example.com)")
                    elif user_exists(email_signup):
                        st.error("❌ This email is already registered. Please Sign In or use a different email.")
                    elif not pwd_signup:
                        st.error("❌ Password is required")
                    elif not pwd_confirm:
                        st.error("❌ Please confirm your password")
                    elif pwd_signup != pwd_confirm:
                        st.error("❌ Passwords do not match. Please try again.")
                    else:
                        # Validate password strength
                        is_strong, errors = validate_password(pwd_signup)
                        if not is_strong:
                            st.error("❌ Password does not meet requirements. " + " ".join(errors))
                        else:
                            # Register user
                            success, message = register_user(name_signup.strip(), email_signup.strip(), pwd_signup)
                            if success:
                                st.success(f"✅ {message}")
                                st.info("Please click the 'Sign In' tab to log in with your new account.")
                            else:
                                st.error(f"❌ {message}")
            
            with col2:
                if st.button("🔄", help="Reset form", key="btn_reset_signup"):
                    st.rerun()

        st.markdown('<div class="divider"><span>Or continue with</span></div>', unsafe_allow_html=True)
        s1, s2, s3 = st.columns(3)
        s1.button("🌐 Google", key="s_google", use_container_width=True)
        s2.button("🍎 Apple", key="s_apple", use_container_width=True)
        s3.button("🔵 Facebook", key="s_fb", use_container_width=True)

    with r_col:
        st.markdown("""
        <div class="right-panel">
            <div style="background: rgba(255,255,255,0.15); padding: 12px 20px; border-radius: 50px; width: fit-content; font-size: 13px; backdrop-filter: blur(15px); margin-bottom: 25px; border: 1px solid rgba(255,255,255,0.2);">
                💎 Premium AI Powered Finance Suite
            </div>
            <h2 style="font-size: 44px; font-weight: 800; line-height: 1.1;">Finally, all your finances in one place.</h2>
            <p style="font-size: 16px; opacity: 0.9; margin-top: 20px; line-height: 1.6;">
                Track savings, predict future wealth, and unlock executive-level financial intelligence.
            </p>
            <p style="font-size: 14px; opacity: 0.8; margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 20px;">
                🔒 Your data is encrypted and secure<br>
                ✅ Create account once, access everywhere<br>
                📊 Real-time financial analytics
            </p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    login_user()
