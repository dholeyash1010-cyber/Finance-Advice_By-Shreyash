"""
utils/investor.py
------------------
Investment Recommendation Engine based on Age, Salary, and Risk Profile.
"""

def get_investment_plan(age, salary, savings, risk_level):
    # 1. Emergency Fund Calculation (Standard 6 months of expenses)
    monthly_expenses = salary - savings
    emergency_fund = monthly_expenses * 6
    
    # 2. Asset Allocation Logic based on Risk and Age (Rule of 100)
    # Standard formula: Equity % = 100 - Age
    base_equity = 100 - age
    
    if risk_level == "Conservative":
        equity_split = base_equity * 0.7
    elif risk_level == "Moderate":
        equity_split = base_equity
    else: # Aggressive
        equity_split = min(base_equity * 1.3, 90)
        
    debt_split = 100 - equity_split

    # 3. Specific Product Recommendations
    recommendations = {
        "Emergency Fund Target": f"₹{emergency_fund:,.0f}",
        "Allocation": {
            "Equity (SIP/Stocks)": f"{equity_split:.0f}%",
            "Debt (FD/PPF/Bonds)": f"{debt_split:.0f}%"
        },
        "Products": []
    }

    if age < 35:
        recommendations["Products"] += ["Direct Equity/Stocks", "Small-cap Mutual Funds"]
    
    recommendations["Products"] += ["Index Mutual Funds", "Public Provident Fund (PPF)"]
    
    if risk_level == "Conservative" or age > 50:
        recommendations["Products"] += ["Fixed Deposits (FD)", "Liquid Funds"]

    return recommendations
