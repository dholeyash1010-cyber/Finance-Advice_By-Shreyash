import pandas as pd

def classify_expenses(df):
    """
    Scans 'Description' and maps to app categories.
    """
    mapping = {
        'Food': ['swiggy', 'zomato', 'restaurant', 'mcdonalds', 'starbucks', 'grocery'],
        'Travel': ['uber', 'ola', 'rapido', 'irctc', 'petrol', 'shell', 'indigo'],
        'Shopping': ['amazon', 'flipkart', 'myntra', 'zara', 'h&m', 'reliance'],
        'Rent': ['rent', 'house', 'maintenance'],
        'EMI': ['loan', 'emi', 'hdfc', 'icici', 'sbi']
    }

    results = {'Salary': 0, 'EMI': 0, 'Rent': 0, 'Food': 0, 'Travel': 0, 'Shopping': 0, 'Others': 0}
    
    # Standardize column names
    df.columns = [c.strip().capitalize() for c in df.columns]
    
    if 'Description' in df.columns and 'Amount' in df.columns:
        for _, row in df.iterrows():
            desc = str(row['Description']).lower()
            amt = abs(float(row['Amount']))
            found = False
            for category, keywords in mapping.items():
                if any(k in desc for k in keywords):
                    results[category] += amt
                    found = True
                    break
            if not found:
                results['Others'] += amt
    return results
