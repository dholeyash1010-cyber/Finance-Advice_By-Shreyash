import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import os

# 1. PAGE CONFIG
st.set_page_config(
    page_title="AI Finance Intelligence",
    page_icon="💎",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# 2. IMPORTS
from home import show_homepage
from login import login_user
from utils.calculations import calculate_finances
from utils.predictor import predict_next_month_savings, predict_all, savings_projection
from utils.advisor import step_by_step_advice as get_detailed_advice
from utils.investor import get_investment_plan
from utils.classifier import classify_expenses
from utils.insights import get_spending_insights

# 3. SESSION & ROUTING
if 'page' not in st.session_state:
    st.session_state.page = "home"
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if st.session_state.page == "home":
    show_homepage()
    st.stop()
elif st.session_state.page == "login" and not st.session_state.logged_in:
    login_user()
    st.stop()
elif not st.session_state.logged_in:
    st.session_state.page = "login"
    st.rerun()

# ─────────────────────────────────────────
# THEME
# ─────────────────────────────────────────
theme = st.toggle("🌙 Dark Mode", value=True)

if theme:
    bg_main, bg_secondary = "#0d3d29", "#1a5a3d"
    card_bg = "rgba(19, 51, 38, 0.88)"
    text_color, sub_text = "#ffffff", "#a8d5b8"
    accent, accent2 = "#2d8659", "#3db870"
    border = "rgba(255,255,255,0.1)"
    chart_color = "#3db870"
else:
    bg_main, bg_secondary = "#e8f5f0", "#c9e9dd"
    card_bg = "#d9f0e8"
    text_color, sub_text = "#0d3d29", "#0d3d29"
    accent, accent2 = "#1a5a3d", "#2d8659"
    border = "rgba(13, 61, 41, 0.12)"
    chart_color = "#1a5a3d"

# ─────────────────────────────────────────
# DATA (SMART LOADER)
# ─────────────────────────────────────────
@st.cache_data
def get_cleaned_data():
    file_path = "userdata.csv"
    if not os.path.exists(file_path):
        return None
    
    try:
        try:
            df = pd.read_csv(file_path)
            if df.empty or "[Content_Types].xml" in str(df.columns[0]):
                df = pd.read_excel(file_path)
        except:
            df = pd.read_excel(file_path)
        
        df.columns = df.columns.str.strip()

        if 'Income' in df.columns: df['Salary'] = df['Income']
        if 'Loan_Repayment' in df.columns: df['EMI'] = df['Loan_Repayment']
        
        if 'Groceries' in df.columns and 'Eating_Out' in df.columns:
            df['Food'] = df['Groceries'] + df['Eating_Out']
            
        if 'Transport' in df.columns: df['Travel'] = df['Transport']
        
        if 'Entertainment' in df.columns and 'Miscellaneous' in df.columns:
            df['Shopping'] = df['Entertainment'] + df['Miscellaneous']
            
        rename_dict = {
            'Monthly Income': 'Salary', 'Rent_Expense': 'Rent',
            'Food_Expense': 'Food', 'Shopping_Others': 'Shopping', 'Emi': 'EMI'
        }
        df.rename(columns=rename_dict, inplace=True)
        
        for col in ['Salary', 'EMI', 'Rent', 'Food', 'Travel', 'Shopping']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
        return df
    except:
        return None

df_full = get_cleaned_data()
all_savings_data = (
    df_full['Salary'].dropna()
    if df_full is not None and 'Salary' in df_full.columns else None
)

# ─────────────────────────────────────────
# CSS
# ─────────────────────────────────────────
st.markdown(f"""
<style>
#MainMenu {{ visibility:hidden; }}
footer {{ visibility:hidden; }}
header {{ visibility:hidden; }}
[data-testid="stSidebar"] {{ display:none; }}

.stApp, .stMarkdown, p, span, label, li, h1, h2, h3, h4, h5, h6, .stSubheader {{
    color: {text_color} !important;
}}
[data-testid="stTextInput"] input, [data-testid="stNumberInput"] input {{
    background-color: #e6f4f1 !important;
    color: #041b16 !important;
    border: 1px solid #b7d4cc !important;
    border-radius: 10px !important;
}}
.stApp {{ background: linear-gradient(135deg, {bg_main}, {bg_secondary}); }}
.hero {{ background: {card_bg}; border: 1px solid {border}; padding: 30px; border-radius: 25px; margin-bottom: 25px; text-align: center; }}
.hero-title {{ font-size: 40px; font-weight: 800; color: {text_color} !important; }}
.glass-card {{ background: {card_bg}; border: 1px solid {border}; padding: 22px; border-radius: 20px; margin-bottom: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }}
.section-title {{ font-size: 20px; font-weight: 700; margin-bottom: 12px; color: {text_color} !important; }}
.metric-box {{ background: {bg_secondary}; border: 1px solid {border}; padding: 15px; border-radius: 15px; text-align: center; }}
.metric-value {{ color: {text_color} !important; font-size: 24px; font-weight: 800; }}
.ai-box {{ background: rgba(31,170,128,0.08); border: 1px solid {accent}; padding: 18px; border-radius: 15px; color: {text_color} !important; font-size: 14px; }}
.ml-badge {{ display:inline-block; background: {accent}; color: white !important; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; margin-right: 6px; }}
.stButton > button {{
    background: linear-gradient(135deg, {accent}, {accent2}) !important;
    color: white !important;
    border-radius: 12px !important;
    padding: 12px !important;
    font-weight: 700 !important;
    border: none !important;
    width: 100% !important;
}}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────
# HEADER
# ─────────────────────────────────────────
col_h1, col_h2 = st.columns([0.9, 0.1])
with col_h2:
    if st.button("🚪 Logout"):
        st.session_state.logged_in = False
        st.session_state.page = "home"
        st.rerun()

st.markdown(f'<div class="hero"><div class="hero-title">💎 AI Finance Intelligence Suite</div><div class="hero-sub">Predictive Analytics • Smart Wealth Tracking • Executive Financial Insights</div></div>', unsafe_allow_html=True)

# ─────────────────────────────────────────
# EQUAL 50/50 LAYOUT
# ─────────────────────────────────────────
left, right = st.columns(2, gap="large")

with left:
    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.markdown(f'<div class="section-title">📂 AI Expense Detection</div>', unsafe_allow_html=True)
    up_file = st.file_uploader("Upload bank statement (CSV)", type="csv")
    if up_file:
        try:
            df_stmt = pd.read_csv(up_file)
            st.session_state.detected = classify_expenses(df_stmt)
            st.success("Analysis Complete! Values updated below.")
        except Exception as e:
            st.error(f"Error processing file: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.markdown(f'<div class="section-title">📌 Financial Inputs</div>', unsafe_allow_html=True)
    def to_flt(v): return float(v) if v and v > 0 else None
    d = st.session_state.get('detected', {})

    salary = st.number_input("Monthly Salary (₹)", min_value=0.0, value=to_flt(d.get('Salary')), placeholder="Enter amount...")
    c1, c2 = st.columns(2)
    with c1:
        emi = st.number_input("EMI (₹)", min_value=0.0, value=to_flt(d.get('EMI')), placeholder="0")
        rent = st.number_input("Rent (₹)", min_value=0.0, value=to_flt(d.get('Rent')), placeholder="0")
        food = st.number_input("Food (₹)", min_value=0.0, value=to_flt(d.get('Food')), placeholder="0")
    with c2:
        travel = st.number_input("Travel (₹)", min_value=0.0, value=to_flt(d.get('Travel')), placeholder="0")
        shopping = st.number_input("Shopping (₹)", min_value=0.0, value=to_flt(d.get('Shopping')), placeholder="0")
        others = st.number_input("Others (₹)", min_value=0.0, value=to_flt(d.get('Others')), placeholder="0")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.markdown(f'<div class="section-title">⚙️ Optimization Engine</div>', unsafe_allow_html=True)
    food_cut = st.slider("Reduce Food Expense (%)", 0, 50, 0)
    shop_cut = st.slider("Reduce Shopping Expense (%)", 0, 50, 0)
    
    st.markdown(f'<div class="section-title" style="margin-top:20px;">💰 Investment Profile</div>', unsafe_allow_html=True)
    age = st.number_input("Your Age", min_value=18, max_value=100, value=25)
    risk_level = st.select_slider("Risk Tolerance", options=["Conservative", "Moderate", "Aggressive"], value="Moderate")
    
    analyze = st.button("GENERATE EXECUTIVE ANALYSIS")
    st.markdown('</div>', unsafe_allow_html=True)

    if analyze and salary is not None:
        def val(x): return float(x) if x is not None else 0.0
        total_exp_ms = val(emi) + val(rent) + (val(food) * (1-food_cut/100)) + val(travel) + (val(shopping) * (1-shop_cut/100)) + val(others)
        opt_savings_ms = salary - total_exp_ms
        savings = opt_savings_ms

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">🚩 Wealth Milestones</div>', unsafe_allow_html=True)
        if opt_savings_ms > 0:
            st.write(f"⏱️ **₹1 Lakh Savings:** {100000/opt_savings_ms:.1f} months")
            st.write(f"⏱️ **₹5 Lakh Savings:** {500000/opt_savings_ms:.1f} months")
        else:
            st.write("⚠️ Deficit detected. Milestones unavailable.")
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">🎯 Investment Recommendation</div>', unsafe_allow_html=True)
        plan = get_investment_plan(age, salary, savings, risk_level)
        i1, i2 = st.columns(2)
        i1.metric("Emergency Goal", plan["Emergency Fund Target"])
        i2.metric("Risk Profile", risk_level)
        st.write("**Suggested Asset Allocation:**")
        alloc_cols = st.columns(len(plan["Allocation"]))
        for idx, (asset, weight) in enumerate(plan["Allocation"].items()):
            alloc_cols[idx].markdown(f"**{asset}** \n{weight}")
        st.write("**Recommended Products:**")
        st.info(" • " + " \n • ".join(plan["Products"]))
        st.markdown('</div>', unsafe_allow_html=True)

with right:
    if analyze and salary is not None:
        def val(x): return float(x) if x is not None else 0.0
        opt_food = val(food) * (1 - food_cut/100)
        opt_shop = val(shopping) * (1 - shop_cut/100)

        total_exp, savings, rate, dist = calculate_finances(
            salary, val(emi), val(rent), opt_food, val(travel), opt_shop + val(others)
        )

        rank = (all_savings_data < salary).mean() * 100 if all_savings_data is not None else 0

        health_score = 100
        if rate < 20: health_score -= 20
        if rate < 10: health_score -= 30
        score_color = "#38d39f" if health_score > 70 else "#f6ad55" if health_score > 40 else "#fc8181"

        st.markdown(f"""
            <div class="glass-card" style="text-align:center; border-top: 5px solid {score_color};">
                <div class="metric-label">OVERALL FINANCIAL HEALTH SCORE</div>
                <div style="font-size:50px; font-weight:900; color:{score_color};">{max(health_score,0)}/100</div>
            </div>
        """, unsafe_allow_html=True)

        m1, m2, m3 = st.columns(3)
        m1.markdown(f'<div class="metric-box"><div class="metric-label">Net Savings</div><div class="metric-value">₹{savings:,.0f}</div></div>', unsafe_allow_html=True)
        m2.markdown(f'<div class="metric-box"><div class="metric-label">Burn %</div><div class="metric-value">{((total_exp/salary)*100 if salary>0 else 0):.0f}%</div></div>', unsafe_allow_html=True)
        m3.markdown(f'<div class="metric-box"><div class="metric-label">Market Rank</div><div class="metric-value">{rank:.0f}%</div></div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">🧠 AI Spending Insights</div>', unsafe_allow_html=True)
        user_exp_dict = {"EMI": val(emi), "Rent": val(rent), "Food": val(food), "Travel": val(travel), "Shopping": val(shopping)}
        spending_insights = get_spending_insights(salary, user_exp_dict, df_full)
        if spending_insights:
            for insight in spending_insights:
                st.write(insight)
        else:
            st.write("Collecting more data to provide comparative insights...")
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">🧠 ML Prediction Engine</div>', unsafe_allow_html=True)
        st.markdown('<span class="ml-badge">Linear Regression</span><span class="ml-badge">Random Forest</span><span class="ml-badge">XGBoost</span>', unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)

        with st.spinner("Training models & predicting..."):
            ml = predict_all(salary, val(emi), val(rent), opt_food, val(travel), opt_shop, val(others))

        p1, p2, p3 = st.columns(3)
        p1.markdown(f'<div class="metric-box"><div class="metric-label">📅 Predicted Savings</div><div class="metric-value">₹{ml["next_month_savings"]:,.0f}</div></div>', unsafe_allow_html=True)
        p2.markdown(f'<div class="metric-box"><div class="metric-label">⚠️ Overspend Risk</div><div class="metric-value">{ml["overspend_risk"]:.0f}/100</div></div>', unsafe_allow_html=True)
        p3.markdown(f'<div class="metric-box"><div class="metric-label">📈 Growth (12M)</div><div class="metric-value">+{ml["investment_growth"]:.1f}%</div></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">🤖 AI Executive Consultant</div>', unsafe_allow_html=True)
        detailed_advice = get_detailed_advice(salary, val(emi), val(rent), opt_food, val(travel), opt_shop + val(others))
        # FIXED: Process line breaks outside of the f-string
        formatted_advice = detailed_advice.replace("\n", "<br>")
        st.markdown(f'<div class="ai-box">{formatted_advice}</div>', unsafe_allow_html=True)
        st.download_button("📝 DOWNLOAD EXECUTIVE AUDIT", detailed_advice, "Financial_Audit.txt")
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title">📈 Visual Analytics Deep-Dive</div>', unsafe_allow_html=True)
        with st.expander("📊 Show Optimized Expense Distribution"):
            fig_pie, ax_pie = plt.subplots(figsize=(3, 3))
            fig_pie.patch.set_alpha(0); ax_pie.pie([val(emi), val(rent), opt_food, val(travel), opt_shop, val(others)], labels=["EMI","Rent","Food","Travel","Shop","Other"], autopct='%1.1f%%', colors=[accent, accent2, "#34d399", "#10b981", "#059669", "#064e3b"], textprops={'color': text_color, 'fontsize': 7})
            st.pyplot(fig_pie)
        with st.expander("📈 Show 12-Month ML Savings Projection"):
            proj = savings_projection(salary, val(emi), val(rent), opt_food, val(travel), opt_shop, val(others), months=12)
            mx = [p[0] for p in proj]; my = [p[1] for p in proj]
            fig_p, ax_p = plt.subplots(figsize=(6, 2.5))
            fig_p.patch.set_alpha(0); ax_p.set_facecolor("none"); ax_p.fill_between(mx, my, alpha=0.2, color=chart_color); ax_p.plot(mx, my, color=chart_color, marker='o', linewidth=2); ax_p.set_xlabel("Month", color=text_color, fontsize=8); ax_p.set_ylabel("Cumulative ₹", color=text_color, fontsize=8); ax_p.tick_params(colors=text_color, labelsize=8)
            st.pyplot(fig_p)
        st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="glass-card" style="height:600px; display:flex; align-items:center; justify-content:center; flex-direction:column; text-align:center;"><div style="font-size:80px;">🤖</div><div style="color:{text_color} !important; font-size:24px; font-weight:700; margin-top:10px;">Executive Analysis Ready</div><div style="color:{text_color} !important; font-size:16px; margin-top:10px; opacity:0.8;">Click generate to unlock ML predictions and visual analytics.</div></div>', unsafe_allow_html=True)
